const { ipcRenderer } = require('electron');
const timer  = require('./timer');

let $ = document.querySelector.bind(document);
let linkSobre = $('#link-sobre');
let botaoPlay = $('.botao-play');
let labelTempo = $('.tempo')

linkSobre.addEventListener('click' , function(){
    ipcRenderer.send('abrir-janela-sobre');
});


let imgs = ['img/play-button.svg', 'img/stop-button.svg'];
botaoPlay.addEventListener('click',function(){
    imgs.reverse();
    timer.iniciar(labelTempo);
    botaoPlay.src = imgs[0];
});
